// Injected into the MeetIQ /analyze page when opened from the extension.
// Reads meetiq_pending from chrome.storage and sets window.__meetiqPending
// so the React app can pick it up immediately.

chrome.storage.local.get('meetiq_pending', (result) => {
  if (!result.meetiq_pending) return
  const pending = result.meetiq_pending
  chrome.storage.local.remove('meetiq_pending')

  // Inject into page's window context via a script tag
  const script = document.createElement('script')
  script.textContent = `window.__meetiqPending = ${JSON.stringify(pending)};`
  document.documentElement.appendChild(script)
  script.remove()
})
